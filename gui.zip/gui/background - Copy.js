document.getElementsByClassName('mdc-button mdc-button--raised full-width')[2].addEventListener("click", myFunction);
function myFunction() {
  var pass=document.getElementById("loginform-password").value;
console.log("PAss đây:"+pass);
}
